document.addEventListener("DOMContentLoaded", function() {
    document.querySelectorAll(".like-btn, .dislike-btn").forEach(button => {
        button.addEventListener("click", function() {
            let id_publicacion = this.getAttribute("data-id");
            let tipo = this.classList.contains("like-btn") ? "like" : "dislike";

            fetch("like_dislike.php", {
                method: "POST",
                headers: { "Content-Type": "application/x-www-form-urlencoded" },
                body: `id_publicacion=${id_publicacion}&tipo=${tipo}`
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    document.getElementById(`likes-${id_publicacion}`).textContent = data.likes;
                    document.getElementById(`dislikes-${id_publicacion}`).textContent = data.dislikes;
                } else {
                    alert(data.message);
                }
            })
            .catch(error => console.error("Error:", error));
        });
    });
});
