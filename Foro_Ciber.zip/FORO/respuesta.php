<?php
session_start();
require_once 'conexion.php';

// Verificar si el usuario está autenticado
if (!isset($_SESSION['nombre_usuario'])) {
    header("Location: login.php");
    exit();
}

// Verificar que id_usuario esté en la sesión
if (!isset($_SESSION['id_usuario']) || empty($_SESSION['id_usuario'])) {
    die("Error: El usuario no está autenticado correctamente.");
}

// Obtener el ID de la publicación desde la URL
$id_publicacion = isset($_GET['id_publicacion']) ? $_GET['id_publicacion'] : 0;

// Obtener la información de la publicación y su autor
$consulta_publicacion = "
    SELECT p.titulo, p.autor AS id_usuario, u.nombre_usuario AS autor, p.num_respuestas, p.fecha 
    FROM publicaciones p
    JOIN usuarios u ON p.autor = u.id_usuario
    WHERE p.id_publicacion = ?
";
$stmt = $conexion->prepare($consulta_publicacion);
$stmt->bind_param('i', $id_publicacion);
$stmt->execute();
$stmt->bind_result($titulo, $id_usuario, $autor, $num_respuestas, $fecha_publicacion);
$stmt->fetch();
$stmt->close();

// Obtener las respuestas para esa publicación
$consulta_respuestas = "
    SELECT r.id_respuesta, r.comentario, u.nombre_usuario AS autor_respuesta, r.fecha
    FROM respuestas r
    JOIN usuarios u ON r.id_usuario = u.id_usuario
    WHERE r.id_publicacion = ?
";
$stmt_respuestas = $conexion->prepare($consulta_respuestas);
$stmt_respuestas->bind_param('i', $id_publicacion);
$stmt_respuestas->execute();
$respuestas_result = $stmt_respuestas->get_result();
$stmt_respuestas->close();
?>

<!DOCTYPE html>
<html>

<head>
    <link rel="stylesheet" href="estilos.css">
    <title>Respuestas - Foro David</title>
    <style>
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }

        table, th, td {
            border: 1px solid black;
        }

        th, td {
            padding: 10px;
            text-align: center;
        }

        th {
            background-color: #f2f2f2;
        }
    </style>
</head>

<body>
<nav>
    <a href="index.php">Inicio</a>
    <a href="crearusuario.php">Crear usuario</a>
    <a href="login.php">Iniciar sesión</a>
    <a href="perfil.php">Perfil</a>

    <?php if (isset($_SESSION['nombre_usuario'])): ?>
        <a href="cerrar_sesion.php">Cerrar sesión</a>
    <?php endif; ?>
</nav>

<h1>Detalles de la Publicación</h1>

<h2><?php echo htmlspecialchars($titulo); ?></h2>
<p><strong>Autor:</strong> <?php echo htmlspecialchars($autor); ?></p>
<p><strong>Fecha de publicación:</strong> <?php echo htmlspecialchars($fecha_publicacion); ?></p>
<p><strong>Número de respuestas:</strong> <?php echo htmlspecialchars($num_respuestas); ?></p>


<?php
// Obtener cantidad de likes y dislikes de la publicación
$sql_votos = "SELECT 
                SUM(CASE WHEN tipo = 'like' THEN 1 ELSE 0 END) AS likes,
                SUM(CASE WHEN tipo = 'dislike' THEN 1 ELSE 0 END) AS dislikes
              FROM votos WHERE id_publicacion = ?";
$stmt = $conexion->prepare($sql_votos);
$stmt->bind_param('i', $id_publicacion);
$stmt->execute();
$stmt->bind_result($likes, $dislikes);
$stmt->fetch();
$stmt->close();
?>


<div>
    <button class="like-btn" data-id="<?= $id_publicacion ?>">👍 <span id="likes-<?= $id_publicacion ?>"><?= $likes ?></span></button>
    <button class="dislike-btn" data-id="<?= $id_publicacion ?>">👎 <span id="dislikes-<?= $id_publicacion ?>"><?= $dislikes ?></span></button>
</div>

<h3>Respuestas</h3>

<table>
    <tr>
        <th>Comentario</th>
        <th>Autor</th>
        <th>Fecha</th>
        <th>Acción</th> <!-- Nueva columna para eliminar respuestas -->
    </tr>

    <?php
    // Mostrar todas las respuestas
    while ($respuesta = $respuestas_result->fetch_assoc()) {
        echo "<tr>";
        echo "<td>" . htmlspecialchars($respuesta['comentario']) . "</td>";
        echo "<td>" . htmlspecialchars($respuesta['autor_respuesta']) . "</td>";
        echo "<td>" . htmlspecialchars($respuesta['fecha']) . "</td>";

        // Mostrar botón de eliminar solo si el usuario es el dueño de la publicación
        if ($_SESSION['id_usuario'] == $id_usuario) {
            echo "<td>
                <form action='eliminar_respuesta.php' method='post'>
                    <input type='hidden' name='id_respuesta' value='" . $respuesta['id_respuesta'] . "'>
                    <input type='hidden' name='id_publicacion' value='" . $id_publicacion . "'>
                    <button type='submit' onclick='return confirm(\"¿Estás seguro de eliminar esta respuesta?\");'>
                        Eliminar
                    </button>
                </form>
            </td>";
        } else {
            echo "<td>-</td>";
        }

        echo "</tr>";
    }
    ?>
</table>

<h3>Añadir respuesta</h3>
<form method="post">
    <textarea name="comentario" required></textarea><br><br>
    <button type="submit">Enviar respuesta</button>
</form>

<?php
// Si se envía una respuesta, guardarla en la base de datos
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['comentario'])) {
    $comentario = trim($_POST['comentario']);

    // Insertar la respuesta en la base de datos
    $insertar_respuesta = "
        INSERT INTO respuestas (comentario, id_publicacion, id_usuario, fecha) 
        VALUES (?, ?, ?, NOW())
    ";

    // Usamos el id_usuario desde la sesión
    $stmt_respuesta = $conexion->prepare($insertar_respuesta);
    $stmt_respuesta->bind_param('sii', $comentario, $id_publicacion, $_SESSION['id_usuario']);

    if ($stmt_respuesta->execute()) {
        // Incrementar el contador de respuestas de la publicación
        $actualizar_respuestas = "
            UPDATE publicaciones 
            SET num_respuestas = num_respuestas + 1 
            WHERE id_publicacion = ?
        ";
        $stmt_actualizar = $conexion->prepare($actualizar_respuestas);
        $stmt_actualizar->bind_param('i', $id_publicacion);
        $stmt_actualizar->execute();
        $stmt_actualizar->close();

        echo "Respuesta añadida con éxito.";
        header("Location: respuesta.php?id_publicacion=" . $id_publicacion);
        exit();
    } else {
        echo "Error al añadir la respuesta: " . mysqli_error($conexion);
    }

    $stmt_respuesta->close();
}
?>
<script src="script.js"></script>
</body>
</html>
