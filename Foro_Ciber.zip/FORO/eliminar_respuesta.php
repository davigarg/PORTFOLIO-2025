<?php
session_start();
require_once 'conexion.php';

// Verificar que el usuario está autenticado
if (!isset($_SESSION['id_usuario'])) {
    die("Error: Debes iniciar sesión.");
}

// Verificar que se haya recibido la respuesta a eliminar
if (!isset($_POST['id_respuesta']) || !isset($_POST['id_publicacion'])) {
    die("Error: Faltan datos.");
}

$id_respuesta = $_POST['id_respuesta'];
$id_publicacion = $_POST['id_publicacion'];

// Verificar que la respuesta pertenece al usuario autenticado
$consulta_autor = "
    SELECT r.id_usuario, p.autor AS id_autor_publicacion
    FROM respuestas r
    JOIN publicaciones p ON r.id_publicacion = p.id_publicacion
    WHERE r.id_respuesta = ?
";
$stmt = $conexion->prepare($consulta_autor);
$stmt->bind_param('i', $id_respuesta);
$stmt->execute();
$stmt->bind_result($id_usuario_respuesta, $id_autor_publicacion);
$stmt->fetch();
$stmt->close();

// Solo el autor de la publicación o el autor de la respuesta pueden eliminarla
if ($_SESSION['id_usuario'] != $id_autor_publicacion && $_SESSION['id_usuario'] != $id_usuario_respuesta) {
    die("Error: No tienes permiso para eliminar esta respuesta.");
}

// Eliminar la respuesta
$consulta_eliminar = "DELETE FROM respuestas WHERE id_respuesta = ?";
$stmt = $conexion->prepare($consulta_eliminar);
$stmt->bind_param('i', $id_respuesta);

if ($stmt->execute()) {
    // Restar 1 al contador de respuestas en la publicación
    $consulta_actualizar = "
        UPDATE publicaciones 
        SET num_respuestas = num_respuestas - 1 
        WHERE id_publicacion = ? AND num_respuestas > 0
    ";
    $stmt_actualizar = $conexion->prepare($consulta_actualizar);
    $stmt_actualizar->bind_param('i', $id_publicacion);
    $stmt_actualizar->execute();
    $stmt_actualizar->close();

    // Redirigir a la página de respuestas
    header("Location: respuesta.php?id_publicacion=" . $id_publicacion);
    exit();
} else {
    echo "Error al eliminar la respuesta: " . $conexion->error;
}

$stmt->close();
?>
