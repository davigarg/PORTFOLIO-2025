<?php
session_start();
require_once 'conexion.php';  // Conexión a la base de datos

// Verificamos si se ha pasado un id_publicacion a través de la URL
if (isset($_GET['id_publicacion'])) {
    $id_publicacion = $_GET['id_publicacion'];  // Obtener el id de la URL
} else {
    // Si no se pasa el id_publicacion, redirigir a otra página o mostrar un error
    echo "No se ha especificado una publicación.";
    exit();
}

// Consultamos la publicación de la base de datos
$sql = "SELECT * FROM publicaciones WHERE id_publicacion = ?";
$stmt = $conexion->prepare($sql);
$stmt->bind_param("i", $id_publicacion);
$stmt->execute();
$resultado = $stmt->get_result();

// Si encontramos la publicación
if ($publicacion = $resultado->fetch_assoc()) {
    echo "<h1>" . $publicacion['titulo'] . "</h1>";
    echo "<p>" . $publicacion['desarrollo'] . "</p>";

    // Si hay un archivo asociado con la publicación, mostrar un enlace de descarga
    if (!empty($publicacion['archivo'])) {
        echo "<a href='uploads/" . $publicacion['archivo'] . "' target='_blank'>Descargar archivo</a>";
    }
} else {
    // Si no se encuentra la publicación con ese id
    echo "Publicación no encontrada.";
}

$stmt->close();
$conexion->close();
?>

