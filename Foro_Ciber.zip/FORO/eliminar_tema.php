<?php
session_start();
include 'conexion.php';

// Verifica si el usuario está logueado
if (!isset($_SESSION['id_usuario'])) {
    header("Location: login.php");
    exit();
}

$id_usuario = $_SESSION['id_usuario'];  // Obtiene el id del usuario desde la sesión

// Verifica si el formulario fue enviado
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $id_publicacion = $_POST['id_publicacion'];

    // Primero elimina las respuestas asociadas a la publicación
    $sql_delete_respuestas = "DELETE FROM respuestas WHERE id_publicacion = ?";
    $stmt_respuestas = $conexion->prepare($sql_delete_respuestas);
    $stmt_respuestas->bind_param("i", $id_publicacion);
    $stmt_respuestas->execute();
    $stmt_respuestas->close();

    // Luego elimina la publicación
    $sql_delete_publicacion = "DELETE FROM publicaciones WHERE id_publicacion = ?";
    $stmt_publicacion = $conexion->prepare($sql_delete_publicacion);
    $stmt_publicacion->bind_param("i", $id_publicacion);
    if ($stmt_publicacion->execute()) {
        echo "Publicación y respuestas eliminadas correctamente.";
    } else {
        echo "Error al eliminar la publicación: " . mysqli_error($conexion);
    }
    $stmt_publicacion->close();
}

// Consulta para obtener las publicaciones del usuario
$sql = "SELECT * FROM publicaciones WHERE autor = $id_usuario";  // Solo las publicaciones del usuario logueado
$resultado = mysqli_query($conexion, $sql);

?>

<!DOCTYPE html>
<html>
<head>
    <link rel="stylesheet" href="estilos.css" >
    <title>Eliminar Publicación</title>
</head>
<body>
    <nav>
        <a href="index.php">Inicio</a>
        <a href="crearusuario.php">Crear usuario</a>
        <a href="login.php">Iniciar sesión</a>
        <a href="perfil.php">Perfil</a>
        <?php if (isset($_SESSION['nombre_usuario'])): ?>
            <a href="cerrar_sesion.php">Cerrar sesión</a>
        <?php endif; ?>
    </nav>

    <h2>Eliminar Publicación</h2>

    <?php
    if (mysqli_num_rows($resultado) > 0) {
        // Si el usuario tiene publicaciones, muestra el formulario
        echo '<form method="post">';
        echo '<label for="id_publicacion">Selecciona una publicación para eliminar:</label>';
        echo '<select name="id_publicacion" id="id_publicacion" required>';
        while ($publicacion = mysqli_fetch_assoc($resultado)) {
            echo '<option value="' . $publicacion['id_publicacion'] . '">' . $publicacion['titulo'] . '</option>';
        }
        echo '</select>';
        echo '<br><button type="submit">Eliminar</button>';
        echo '</form>';
    } else {
        echo "No tienes publicaciones para eliminar.";
    }
    ?>

</body>
</html>
