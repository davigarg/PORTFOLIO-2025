<?php
session_start();
if (!isset($_SESSION['nombre_usuario'])) {
    header("Location: login.php");
    exit();
}

?>

<!DOCTYPE html>
<html>

<head>
    <link rel="stylesheet" href="estilos.css" >
    <title>Perfil - Foro David</title>
    <style>
        nav {
            background-color: #333;
            overflow: hidden;
        }

        nav a {
            float: left;
            display: block;
            color: white;
            text-align: center;
            padding: 14px 16px;
            text-decoration: none;
            transition: background-color 0.3s ease;
        }

        nav a:hover {
            background-color: #111;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }

        table, th, td {
            border: 1px solid black;
        }

        th, td {
            padding: 10px;
            text-align: center;
        }

        th {
            background-color: #f2f2f2;
        }

        td a {
            text-decoration: none;
            color: #0066cc;
        }

        td a:hover {
            color: #0044cc;
        }

    </style>
</head>

<body>
<nav>
    <a href="index.php">Inicio</a>
    <a href="crearusuario.php">Crear usuario</a>
    <a href="login.php">Iniciar sesión</a>
    <a href="perfil.php">Perfil</a>

    <?php if (isset($_SESSION['nombre_usuario'])): ?>
        <a href="cerrar_sesion.php">Cerrar sesión</a>
    <?php endif; ?>
</nav>


    <h1>Bienvenido <?php echo htmlspecialchars($_SESSION['nombre_usuario']); ?></h1>
    <h2>Publicaciones</h2>
    <a id="tema" href="insertartema.php">Agregar un nuevo tema</a>
    <br><br>
    <a href="eliminar_tema.php">Eliminar Tema</a>


    <?php
    require_once 'conexion.php';

    $consulta = "
        SELECT p.id_publicacion, u.nombre_usuario AS autor, p.titulo, p.fecha, p.num_respuestas 
        FROM publicaciones p
        JOIN usuarios u ON p.autor = u.id_usuario
    ";
    $resultado = mysqli_query($conexion, $consulta);

    if ($resultado) {
        echo "<table>";
        echo "<tr>
                <td>Autor</td>
                <td>Título</td>
                <td>Fecha</td>
                <td>Respuestas</td>
                <td>Ver</td>   
              </tr>";
        
        while ($fila = mysqli_fetch_assoc($resultado)) {
            echo "<tr>";
            echo "<td>" . htmlspecialchars($fila['autor']) . "</td>";  
            echo "<td>" . htmlspecialchars($fila['titulo']) . "</td>"; 
            echo "<td>" . htmlspecialchars($fila['fecha']) . "</td>";    
            echo "<td>" . htmlspecialchars($fila['num_respuestas']) . "</td>"; 
            echo "<td><a href='respuesta.php?id_publicacion=" . $fila['id_publicacion'] . "'>Ver</a></td>"; 
            echo "</tr>";
        }
        
        echo "</table>";
    } else {
        echo "Error al obtener las publicaciones: " . mysqli_error($conexion);
    }
    ?>
</body>

</html>
