<?php
session_start();
require_once 'conexion.php';

// Verificar si el usuario está autenticado
if (!isset($_SESSION['id_usuario'])) {
    echo json_encode(['success' => false, 'message' => 'Debes iniciar sesión']);
    exit();
}

$id_usuario = $_SESSION['id_usuario'];
$id_publicacion = $_POST['id_publicacion'];
$tipo = $_POST['tipo']; // 'like' o 'dislike'

// Comprobar si el usuario ya votó en esta publicación
$sql_check = "SELECT tipo FROM votos WHERE id_usuario = ? AND id_publicacion = ?";
$stmt = $conexion->prepare($sql_check);
$stmt->bind_param('ii', $id_usuario, $id_publicacion);
$stmt->execute();
$stmt->bind_result($voto_actual);
$stmt->fetch();
$stmt->close();

if ($voto_actual) {
    if ($voto_actual == $tipo) {
        // Si el usuario hace clic en el mismo botón, eliminar su voto
        $sql_delete = "DELETE FROM votos WHERE id_usuario = ? AND id_publicacion = ?";
        $stmt = $conexion->prepare($sql_delete);
        $stmt->bind_param('ii', $id_usuario, $id_publicacion);
        $stmt->execute();
        $stmt->close();
    } else {
        // Si el usuario cambia de opinión, actualizar su voto
        $sql_update = "UPDATE votos SET tipo = ? WHERE id_usuario = ? AND id_publicacion = ?";
        $stmt = $conexion->prepare($sql_update);
        $stmt->bind_param('sii', $tipo, $id_usuario, $id_publicacion);
        $stmt->execute();
        $stmt->close();
    }
} else {
    // Si el usuario no ha votado antes, insertar su voto
    $sql_insert = "INSERT INTO votos (id_usuario, id_publicacion, tipo) VALUES (?, ?, ?)";
    $stmt = $conexion->prepare($sql_insert);
    $stmt->bind_param('iis', $id_usuario, $id_publicacion, $tipo);
    $stmt->execute();
    $stmt->close();
}

// Contar likes y dislikes actualizados
$sql_count = "SELECT 
                SUM(CASE WHEN tipo = 'like' THEN 1 ELSE 0 END) AS likes,
                SUM(CASE WHEN tipo = 'dislike' THEN 1 ELSE 0 END) AS dislikes
              FROM votos WHERE id_publicacion = ?";
$stmt = $conexion->prepare($sql_count);
$stmt->bind_param('i', $id_publicacion);
$stmt->execute();
$stmt->bind_result($likes, $dislikes);
$stmt->fetch();
$stmt->close();

// Enviar respuesta en formato JSON
echo json_encode(['success' => true, 'likes' => $likes, 'dislikes' => $dislikes]);
?>
