<?php
session_start(); // Iniciar la sesión
session_destroy(); // Destruir la sesión
header("Location: index.php"); // Mandar a la página principal
exit();
?>
