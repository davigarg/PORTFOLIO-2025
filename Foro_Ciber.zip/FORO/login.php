<?php
session_start(); // Asegúrate de que esta línea esté presente

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    require_once 'conexion.php'; // Incluir el archivo de conexión

    $nombre_usuario = $_POST['usuario'];
    $contrasena = $_POST['password'];

    // Consulta la base de datos para verificar las credenciales
    $consulta = "SELECT * FROM usuarios WHERE nombre_usuario = '$nombre_usuario'";
    $resultado = mysqli_query($conexion, $consulta);

    if (mysqli_num_rows($resultado) == 1) {
        $fila = mysqli_fetch_assoc($resultado);
        $contrasena_almacenada = $fila['contrasena'];

        // Verifica si la contraseña ingresada coincide con la almacenada (SIN HASHEAR)
        if ($contrasena == $contrasena_almacenada) {
            $_SESSION['nombre_usuario'] = $nombre_usuario;
            $_SESSION['id_usuario'] = $fila['id_usuario'];

            $fecha_hora = date("Y-m-d H:i:s"); 
            $acceso = "Usuario: $nombre_usuario - Fecha/Hora: $fecha_hora\n";
            file_put_contents("accesos.txt", $acceso, FILE_APPEND); 

           
            header("Location: perfil.php");
            exit(); 
        } else {
            $error = "Contraseña incorrecta.";
        }
    } else {
        $error = "Nombre de usuario no encontrado.";
    }
}
?>

<!doctype html>
<html>
<head>
    <link rel="stylesheet" href="estilos.css">
    <title>Iniciar sesión</title>
    <style>
        nav {
            background-color: #333;
            overflow: hidden;
        }

        nav a {
            float: left;
            display: block;
            color: white;
            text-align: center;
            padding: 14px 16px;
            text-decoration: none;
            transition: background-color 0.3s ease; 
        }

        nav a:hover {
            background-color: #111; 
        }
    </style>
</head>
<body>
<nav>
    <a href="index.php">Inicio</a>
    <a href="crearusuario.php">Crear usuario</a>
    <a href="login.php">Iniciar sesión</a>
    <a href="perfil.php">Perfil</a>

    <?php if (isset($_SESSION['nombre_usuario'])): ?>
        <a href="cerrar_sesion.php">Cerrar sesión</a>
    <?php endif; ?>
</nav>

    <h1>Login</h1>
    <br>
    <br>

    <form name="miformulario" method="post" onsubmit="return validarFormulario()">
        User
        <input type="text" name="usuario"><br>
        Password
        <input type="password" name="password"><br>
        <input type="submit" value="Login">
    </form>
</body>
</html>
