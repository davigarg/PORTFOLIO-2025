<?php
session_start();
if (!isset($_SESSION['nombre_usuario'])) {
    header("Location: login.php");
    exit();
}

// Obtener el id del usuario desde la base de datos
require_once 'conexion.php'; // Conexión a la base de datos
$nombre_usuario = $_SESSION['nombre_usuario'];
$query = "SELECT id_usuario FROM usuarios WHERE nombre_usuario = ?";
$stmt = $conexion->prepare($query);
$stmt->bind_param('s', $nombre_usuario);
$stmt->execute();
$stmt->bind_result($id_usuario);
$stmt->fetch();
$stmt->close();

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $titulo = trim($_POST['titulo']);
    $contenido = trim($_POST['contenido']);
    $autor = $id_usuario; // Ahora usamos el id_usuario en lugar del nombre_usuario

    // Procesamos el archivo si existe
    $ruta_archivo = null; // Inicializamos la variable de archivo

    if (isset($_FILES['archivo']) && $_FILES['archivo']['error'] == 0) {
        // Carpeta donde se guardarán los archivos subidos
        $directorio_subida = 'uploads/';
        $archivo_subido = $directorio_subida . basename($_FILES['archivo']['name']);

        // Comprobamos si el archivo se puede mover al directorio
        if (move_uploaded_file($_FILES['archivo']['tmp_name'], $archivo_subido)) {
            // Si el archivo se sube correctamente, guardamos la ruta
            $ruta_archivo = $archivo_subido;
        } else {
            echo "Error al subir el archivo.";
        }
    }

    // Verificamos si los campos son válidos
    if (empty($titulo) || empty($contenido)) {
        echo "Todos los campos son obligatorios.";
    } else {
        // Insertamos el tema en la base de datos con la ruta del archivo
        $query = "INSERT INTO publicaciones (titulo, desarrollo, autor, fecha, num_respuestas, archivo) 
                  VALUES (?, ?, ?, NOW(), 0, ?)";

        $stmt = mysqli_prepare($conexion, $query);
        mysqli_stmt_bind_param($stmt, "ssss", $titulo, $contenido, $autor, $ruta_archivo);

        if (mysqli_stmt_execute($stmt)) {
            header("Location: perfil.php"); // Redirigir después de insertar
            exit();
        } else {
            echo "Error al insertar la publicación: " . mysqli_error($conexion);
        }

        mysqli_stmt_close($stmt);
    }
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <link rel="stylesheet" href="estilos.css" >
    <meta charset="UTF-8">
    <title>Agregar Nuevo Tema</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            text-align: center;
            margin: 50px;
        }
        .formulario {
            width: 50%;
            margin: auto;
            padding: 20px;
            border: 1px solid #ccc;
            border-radius: 5px;
            background-color: #f9f9f9;
        }
        input, textarea {
            width: 90%;
            margin: 10px 0;
            padding: 8px;
        }
        button {
            background-color: #007BFF;
            color: white;
            padding: 10px;
            border: none;
            cursor: pointer;
        }
        button:hover {
            background-color: #0056b3;
        }
    </style>
</head>
<body>
<nav>
    <a href="index.html">Inicio</a>
    <a href="crearusuario.php">Crear usuario</a>
    <a href="login.php">Iniciar sesión</a>
    <a href="perfil.php">Perfil</a>

    <?php if (isset($_SESSION['nombre_usuario'])): ?>
        <a href="cerrar_sesion.php">Cerrar sesión</a>
    <?php endif; ?>
</nav>

<div class="formulario">
    <h2>📝 Crear Nuevo Tema</h2>
    <form method="post" name="miformulario" enctype="multipart/form-data" onsubmit="return validarCampos()">
    <label><strong>Título:</strong></label>
    <input type="text" name="titulo" required>

    <label><strong>Contenido:</strong></label>
    <textarea name="contenido" required></textarea>

    <label><strong>Subir un archivo (opcional):</strong></label>
    <input type="file" name="archivo">

    <button type="submit">Publicar</button>
</form>

</div>

<script>
    function validarCampos() {
        var titulo = document.forms["miformulario"]["titulo"].value;
        var contenido = document.forms["miformulario"]["contenido"].value;

        if (titulo == "" || contenido == "") {
            if (titulo == "") {
                document.getElementsByName("titulo")[0].style.border = "2px solid red";
            }
            if (contenido == "") {
                document.getElementsByName("contenido")[0].style.border = "2px solid red";
            }
            return false;
        }
        return true;
    }
</script>

</body>
</html>
