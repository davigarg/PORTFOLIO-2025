<!doctype html>
<html>

<head>
<link rel="stylesheet" href="estilos.css" >
    <title>Crear Usuario</title>
<style>
        nav {
            background-color: #333;
            overflow: hidden;
        }

        nav a {
            float: left;
            display: block;
            color: white;
            text-align: center;
            padding: 14px 16px;
            text-decoration: none;
            transition: background-color 0.3s ease; 
        }

        nav a:hover {
            background-color: #111; 
        }
    </style>
</head>

<body>
<nav>
    <a href="index.php">Inicio</a>
    <a href="crearusuario.php">Crear usuario</a>
    <a href="login.php">Iniciar sesión</a>
    <a href="perfil.php">Perfil</a>

    <?php if (isset($_SESSION['nombre_usuario'])): ?>
        <a href="cerrar_sesion.php">Cerrar sesión</a>
    <?php endif; ?>
</nav>

    <h1>Crear usuario</h1>
    <br>
    <br>

    <form name="miformulario" method="post" onsubmit="return validarFormulario()">
        Introduce nombre
        <input type="text" name="usuario" value="nombre"><br>
        Password
        <input type="text" name="password" value="password"><br>
        <input type="submit" value="Login">

    </form>

    <script>
    function validarFormulario() {
        var usuario = document.forms["miformulario"]["usuario"].value;
        var password = document.forms["miformulario"]["password"].value;
        
        var regexNombre = /^[a-zA-Z0-9._-]{10,30}$/;  // Para verificar que tenga 10-30 caracteres y no empiece con número
        var regexPassword = /^(?=.*[0-9])(?=.*[A-Z]).{5,20}$/; // Para verificar la contraseña
        
        if (!regexNombre.test(usuario)) {
            alert("El nombre de usuario debe tener entre 10 y 30 caracteres y no puede comenzar con un número.");
            return false;
        }
        if (!regexPassword.test(password)) {
            alert("La contraseña debe contener al menos un número, una letra mayúscula y tener entre 5 y 20 caracteres.");
            return false;
        }
        return true;
    }
</script>

</body>

<?php

// Incluir el archivo de conexión a la base de datos
require_once 'conexion.php';

//si pulsamos el botón de enviar, se crea un array del sistema, que guarda los datos
//del formulario
if ($_POST) {
    //creamos dos variables
    $nombre = $_POST['usuario'];
    $password = $_POST['password'];

    // Insertamos los datos en la tabla Usuarios utilizando sentencias preparadas
    $consulta = "INSERT INTO usuarios (nombre_usuario, contrasena) VALUES (?, ?)";
    $stmt = mysqli_prepare($conexion, $consulta);

    // Vinculamos los parámetros a la consulta
    mysqli_stmt_bind_param($stmt, "ss", $nombre, $password); // "ss" indica dos strings

    // Ejecutamos la consulta
    if (mysqli_stmt_execute($stmt)) {
        echo "El proceso de alta se ha completado de forma correcta!!!!";
    } else {
        echo "Error al registrar usuario: " . mysqli_error($conexion);
    }

    // Cerramos la sentencia preparada
    mysqli_stmt_close($stmt);


    //Redirigir a php, login
 header('Location:login.php');
}
?>

</html>