document.addEventListener('DOMContentLoaded', function() {
    // Verificamos si el usuario ya aceptó las cookies
    if (localStorage.getItem('cookies-accepted') === 'true') {
        // Si el usuario ya aceptó las cookies, ocultamos el mensaje
        document.getElementById('cookie-message').style.display = 'none';
    } else {
        // Si no se ha aceptado, mostramos el mensaje
        document.getElementById('cookie-message').style.display = 'flex';
    }

    // Agregamos el evento click para el botón "Aceptar"
    document.getElementById('accept-cookies').addEventListener('click', function() {
        // Ocultamos el mensaje de cookies
        document.getElementById('cookie-message').style.display = 'none';
        
        // Guardamos en localStorage que el usuario aceptó las cookies
        localStorage.setItem('cookies-accepted', 'true');
    });
});
