<?php
$contador_archivo = 'contador.txt';

if (file_exists($contador_archivo)) {
    // Leemos el número actual de visitas
    $contador = file_get_contents($contador_archivo);
    $contador = (int)$contador; // Convertir a número entero
} else {
    $contador = 0;
}
$contador++;

file_put_contents($contador_archivo, $contador);
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Foro Ciberseguridad - Inicio</title>
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;700&display=swap" rel="stylesheet">
    <style>
        body {
            font-family: 'Roboto', sans-serif;
            margin: 0;
            padding: 0;
            background-image: url('https://th.bing.com/th/id/R.1305eed3717a9148a2f7ba3887b922cf?rik=YDLNvqCLFP%2fRWg&riu=http%3a%2f%2fuserscontent2.emaze.com%2fimages%2f60491a2e-185c-432f-9857-f463b08a165b%2ff333a64e-6e69-4c47-83cf-79ae9982e216.jpg&ehk=83sfM0QVrtIhVBROEuy6kizoGJffGIRY7WiqWagq3cQ%3d&risl=&pid=ImgRaw&r=0'); /* Imagen de fondo */
            background-size: cover;
            background-repeat: no-repeat;
            color: #fff;
        }

        .cookie-message {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0, 0, 0, 0.8);
            color: white;
            display: flex;
            justify-content: center;
            align-items: center;
            font-size: 18px;
            text-align: center;
            z-index: 1000;
        }

        .cookie-message p {
            margin: 0;
        }

        #accept-cookies {
            padding: 10px 20px;
            margin-top: 10px;
            background-color: #4CAF50;
            color: white;
            border: none;
            cursor: pointer;
        }

        #accept-cookies:hover {
            background-color: #45a049;
        }

        .container {
            max-width: 800px;
            margin: 50px auto;
            padding: 20px;
            background-color: rgba(0, 0, 0, 0.5);
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            text-align: center;
        }

        header h1 {
            font-size: 2.5rem;
            margin-bottom: 10px;
            color: #fff;
        }

        header p {
            font-size: 1.2rem;
            color: #eee;
        }

        nav {
            margin-top: 20px;
        }

        .btn {
            display: inline-block;
            padding: 10px 20px;
            margin: 0 10px;
            font-size: 1rem;
            color: #fff;
            background-color: #3498db;
            border-radius: 5px;
            text-decoration: none;
            transition: background-color 0.3s ease;
        }

        .btn:hover {
            background-color: #2980b9;
        }

        .visit-counter {
            font-size: 1.2rem;
            color: #fff;
            margin-top: 20px;
        }
    </style>
</head>
<body>


<div id="cookie-message" class="cookie-message">
    <p>Este sitio web utiliza cookies para mejorar tu experiencia. Al continuar navegando, aceptas su uso. 
        <button id="accept-cookies">Aceptar</button>
    </p>
</div>

<div class="container">
    <header>
        <h1>Bienvenido al Foro de Ciberseguridad</h1>
        <p>Comparte conocimientos, aprende y debate sobre seguridad informática.</p>
    </header>
    <nav>
        <a href="crearusuario.php" class="btn">Crear Usuario</a>
        <a href="login.php" class="btn">Iniciar Sesión</a>
    </nav>

    <div class="forum-description">
        <h2>¿De qué trata este foro?</h2>
        <p>Este es un espacio dedicado a la discusión y el aprendizaje sobre ciberseguridad. Aquí podrás encontrar información sobre temas como:</p>
        <ul>
            <li>Pentesting y Ethical Hacking</li>
            <li>Seguridad de redes</li>
            <li>Análisis de malware</li>
            <li>Criptografía</li>
            <li>Seguridad web</li>
            <li>Y mucho más...</li>
        </ul>
        <p>¡Únete a la comunidad y comparte tus conocimientos!</p>
    </div>


    <div class="visit-counter">
        <p>Visitas al foro: <?php echo $contador; ?></p>
    </div>

</div>


<script src="cookies.js"></script>

</body>
</html>
